/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Category = 'Vaca' | 'Vaquillona' | 'Novillo' | 'Toro' | 'Ternero';

export interface AnimalReading {
  id: string;
  timestamp: Date;
  tagNumber: string;
  rfidCode: string;
  breed: string;
  category: Category;
  age: string;
  reproductionStatus: string;
  bodyCondition: number; // 1-5
  weight: number;
  alerts: string[];
}

export type ConnectionStatus = 'disconnected' | 'connecting' | 'connected';
